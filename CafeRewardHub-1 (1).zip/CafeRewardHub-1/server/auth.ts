import passport from "passport";
import { Strategy as LocalStrategy } from "passport-local";
import { Express } from "express";
import session from "express-session";
import { scrypt, randomBytes, timingSafeEqual } from "crypto";
import { promisify } from "util";
import { storage } from "./storage";
import { User as SelectUser } from "@shared/schema";

declare global {
  namespace Express {
    interface User extends SelectUser {}
  }
}

const scryptAsync = promisify(scrypt);

async function hashPassword(password: string) {
  const salt = randomBytes(16).toString("hex");
  const buf = (await scryptAsync(password, salt, 64)) as Buffer;
  return `${buf.toString("hex")}.${salt}`;
}

async function comparePasswords(supplied: string, stored: string) {
  const [hashed, salt] = stored.split(".");
  const hashedBuf = Buffer.from(hashed, "hex");
  const suppliedBuf = (await scryptAsync(supplied, salt, 64)) as Buffer;
  return timingSafeEqual(hashedBuf, suppliedBuf);
}

export function setupAuth(app: Express) {
  const sessionSettings: session.SessionOptions = {
    secret: process.env.SESSION_SECRET || "CafeRewardsSecretKey",
    resave: false,
    saveUninitialized: false,
    store: storage.sessionStore,
    cookie: {
      secure: process.env.NODE_ENV === "production",
      maxAge: 1000 * 60 * 60 * 24 * 7, // 1 week
    }
  };

  app.set("trust proxy", 1);
  app.use(session(sessionSettings));
  app.use(passport.initialize());
  app.use(passport.session());

  passport.use(
    new LocalStrategy(async (username, password, done) => {
      try {
        const user = await storage.getUserByUsername(username);
        if (!user || !(await comparePasswords(password, user.password))) {
          return done(null, false, { message: "Invalid username or password" });
        } else {
          return done(null, user);
        }
      } catch (error) {
        return done(error);
      }
    }),
  );

  passport.serializeUser((user, done) => done(null, user.id));
  passport.deserializeUser(async (id: number, done) => {
    try {
      const user = await storage.getUser(id);
      done(null, user);
    } catch (error) {
      done(error);
    }
  });

  // Cafe owner registration endpoint
  app.post("/api/register", async (req, res, next) => {
    try {
      const { role, name, email, phone, ...userData } = req.body;
      
      // Validate required fields
      if (!userData.username || !userData.password || !name) {
        return res.status(400).json({ message: "Missing required fields" });
      }

      // Only cafe owners can register through the main registration endpoint
      if (role !== "owner") {
        return res.status(400).json({ message: "Only cafe owners can register through this endpoint" });
      }

      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create the user
      const hashedPassword = await hashPassword(userData.password);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
        role: "owner", // Enforce owner role
        name,
        email,
        phone,
      });

      // Create a default cafe for the owner
      await storage.createCafe({
        name: `${name}'s Cafe`,
        address: "",
        phone: phone || "",
        email: email || "",
        whatsappEnabled: false,
        plan: "trial",
        ownerId: user.id,
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });
  
  // Customer registration endpoint - requires cafeId
  app.post("/api/register/customer/:cafeId", async (req, res, next) => {
    try {
      const { name, email, phone, ...userData } = req.body;
      const cafeId = parseInt(req.params.cafeId);
      
      // Validate required fields
      if (!userData.username || !userData.password || !name) {
        return res.status(400).json({ message: "Missing required fields" });
      }
      
      // Verify that the cafe exists
      const cafe = await storage.getCafeById(cafeId);
      if (!cafe) {
        return res.status(404).json({ message: "Cafe not found" });
      }

      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      // Create the user
      const hashedPassword = await hashPassword(userData.password);
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword,
        role: "customer", // Enforce customer role
        name,
        email,
        phone,
      });
      
      // Create customer profile linked to the specific cafe
      await storage.createCustomerProfile({
        userId: user.id,
        cafeId: cafeId,
        name: name,
        email: email || "",
        phone: phone || "",
        points: 0,
        totalOrders: 0,
        totalSpent: "0",
      });

      req.login(user, (err) => {
        if (err) return next(err);
        res.status(201).json(user);
      });
    } catch (error) {
      next(error);
    }
  });

  app.post("/api/login", (req, res, next) => {
    passport.authenticate("local", (err, user, info) => {
      if (err) return next(err);
      if (!user) {
        return res.status(401).json({ message: info?.message || "Invalid username or password" });
      }
      req.login(user, (err) => {
        if (err) return next(err);
        res.status(200).json(user);
      });
    })(req, res, next);
  });

  app.post("/api/logout", (req, res, next) => {
    req.logout((err) => {
      if (err) return next(err);
      res.sendStatus(200);
    });
  });

  app.get("/api/user", (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    res.json(req.user);
  });
}
